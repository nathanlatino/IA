# Experimentations
* L’utilisation des différentes heuristiques a-t-elle une influence sur l’efficacité de la recherche ?
 (en termes du nombres de noeuds visités)
 
    Oui, Quand l'on teste les différents heuristiques on voit que le chemin choisit et sa distance diffère.
    L'algorithme des heuristiques sont différents et il y a des prioritées différentes. Nous avons juste besoin d'un heuristique admissible
    
 *  Pouvez-vous trouver des exemples où l’utilisation de différentes heuristiques donne des résul-
    tats différents en termes de chemin trouvé ?
    
    Amsterdam à Prague on peut voir qu'il que l h4 (non admissible) ne prend pas le chemin le plus court et n'est pas le plus optimisé

* Dans un cas réel, quelle heuristique utiliseriez-vous ?

    La plus part des résultats donne que le parcours le plus court est souvent celui utilisé avec l'heuristique "vol d'oiseau"
